    <div class="body_container">
        <div class="content">
            <div class="title">
                <h1><i class="fas fa-tools"></i> Maintenances</h1>
                <hr>
            </div>
            <!-- BUTTONS ABOVE THE FORMS / TABLE -->
            <div class="maintenance_nav">
                <a href="../Violation Maintenance Program/" class="maintenance_nav_bttn<?php if ($sub_page == 'vmain_program'){ echo '_active';}?>">
                    Curriculum
                </a>
                <a href="../Violation Maintenance Violation/" class="maintenance_nav_bttn<?php if ($sub_page == 'vmain_violation'){ echo '_active';}?>">
                    Violation
                </a>
                <a href="../Violation Maintenance Academic Year/" class="maintenance_nav_bttn<?php if ($sub_page == 'vmain_acad_yr'){ echo '_active';}?>">
                    Academic Year
                </a>
                <a href="../Violation Maintenance Student Details/" class="maintenance_nav_bttn<?php if ($sub_page == 'vmain_stud_details'){ echo '_active';}?>">
                    </i>Students
                </a>
                <a href="../Violation Maintenance Student Maintenance/" class="maintenance_nav_bttn<?php if ($sub_page == 'vmain_stud_main'){ echo '_active';}?>">
                    </i>Students Maintenance
                </a>
            </div>