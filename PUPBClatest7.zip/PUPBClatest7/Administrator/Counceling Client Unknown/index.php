<?php
    $title = 'Counceling Client Unknown';
    $page = 'ca_client';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="client_content">
            <div class="title">
                <h1>Client Page</h1>
                <hr>
            </div>

            <div class="searchBar">
                <a href="../Counceling Client Page/" class="back_bttn"><i class="fas fa-arrow-left"></i></a>
                <form action="">
                    <input type="text" placeholder="Search" class="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <div class="content_statement">
                <div class="statement">
                    <i class="fas fa-question"></i>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean fringilla nec ante vel vestibulum. Sed id nibh tincidunt,
                        volutpat risus eu, dignissim risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                </div>

            </div>
            
            

        </div>

    </div>
</body>

</html>