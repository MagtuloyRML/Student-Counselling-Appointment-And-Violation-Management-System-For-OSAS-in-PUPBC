<?php
    $title = 'Add Administrator';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>
    <div class="select_container">

        <div class="selection">

            <div class="reg_form">
                <div class="title">
                    <h1>Client Registration</h1>
                    <hr>
                </div>

                <form action="#" method="#">
                    <div class="input_group">
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Username" name="usrnm">
                            <i class="fas fa-lock"></i>
                        </div>
                    </div>
                    <div class="bttn_group">
                        <div class="reg_bttn">
                            <button class="selection_bttn"><i class="fas fa-sign-in-alt"></i>Add Administrator</button>
                        </div>
                    </div>
                </form>
            </div>
            
            
            

        </div>

    </div>
    
</body>
</html>