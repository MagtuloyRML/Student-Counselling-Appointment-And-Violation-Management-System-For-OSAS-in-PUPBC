-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 26, 2022 at 04:17 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientaccountinfo`
--

CREATE TABLE `clientaccountinfo` (
  `ClientAccountID` int(11) NOT NULL,
  `ClientFirstName` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ClientMiddleName` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `ClientLastName` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ClientSuffix` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `ClientStudentNo` varchar(15) CHARACTER SET latin1 NOT NULL,
  `RoleID` int(11) NOT NULL,
  `ClientBDay` date NOT NULL,
  `ClientAddress` text CHARACTER SET latin1 NOT NULL,
  `ClientContactNo` varchar(25) CHARACTER SET latin1 NOT NULL,
  `ClientGuardian` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ClientGuardianNo` varchar(25) CHARACTER SET latin1 NOT NULL,
  `ClientEmailAdd` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ClientPassword` varchar(32) CHARACTER SET latin1 NOT NULL,
  `ClientGenderID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clientaccountinfo`
--

INSERT INTO `clientaccountinfo` (`ClientAccountID`, `ClientFirstName`, `ClientMiddleName`, `ClientLastName`, `ClientSuffix`, `ClientStudentNo`, `RoleID`, `ClientBDay`, `ClientAddress`, `ClientContactNo`, `ClientGuardian`, `ClientGuardianNo`, `ClientEmailAdd`, `ClientPassword`, `ClientGenderID`) VALUES
(1, 'Sample', 'Sample', 'Sample', '', 'Sample', 1, '1999-01-01', 'Sample address', 'sample', 'sample', 'sample', 'sample', 'sample', 1),
(2, 'Sample1', 'Sample1', 'Sample1', '', 'sample1', 1, '2022-01-20', 'Sample address1', 'sample1', 'sample1', 'sample1', 'ermilmagtuloy', 'paramore', 1),
(32, 'Deigo', '', 'Malsamal', '', '2018-00003-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Berta', '09090909090', 'dMamal@gmail.com', 'paramore123', 1),
(34, 'Ernesto', '', 'Ramos', '', '2019-00001-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Sample Guardian', '09090909090', 'mema@gamil.com', 'paramore123', 1),
(35, 'Remy', '', 'Daldalso', '', '2019-00111-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Sample Guardian', '09090909090', 'remd@gmail.com', 'paramore123', 2),
(36, 'Sinangdomeng', '', 'Bigas', '', '2017-00154-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Sample Guardian', '09090909090', 'bgas@gmail.com', 'paramore123', 1),
(37, 'Juana', 'Sample', 'De la Cruz', '', '2018-00008-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Berta', '09090909090', 'juana@gmail.com', 'paramore123', 2),
(38, 'Juanita', '', 'Valdez', '', '2016-00154-BN-0', 1, '2022-01-01', 'Sample address', '09090909090', 'Sample Guardian', '09090909090', 'juanita@gmail.com', 'paramore123', 1),
(39, 'Brian', 'Buendia', 'Pacheca', '', '2018-00154-BN-0', 1, '2000-04-22', 'Munti', '09123456789', 'Mother', '09123456789', 'kasdk@gmail.com', 'asdasdasd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `genderrole`
--

CREATE TABLE `genderrole` (
  `GenderID` int(11) NOT NULL,
  `Description` varchar(25) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `genderrole`
--

INSERT INTO `genderrole` (`GenderID`, `Description`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `email_add` varchar(255) NOT NULL,
  `start_app` datetime NOT NULL,
  `end_app` datetime NOT NULL,
  `stat` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `title`, `email_add`, `start_app`, `end_app`, `stat`, `remarks`) VALUES
(1, 'Meet with Me', '', '2021-11-27 08:00:00', '2021-11-27 09:00:00', '', ''),
(2, '', '', '2021-12-01 23:00:00', '2021-12-01 23:30:00', '', ''),
(3, 'Meeting with Bri', '', '2021-12-02 12:00:00', '2021-12-02 13:00:00', '', ''),
(4, 'Meeting with Bri Again', '', '2021-12-05 22:00:00', '2021-12-05 23:00:00', 'Confirmed', ''),
(5, 'Meeting with Bri Again 2', '', '2021-12-06 08:00:00', '2021-12-06 09:00:00', 'Confirmed', ''),
(6, 'Meet', '', '2021-12-06 10:30:00', '2021-12-06 11:30:00', 'Cancelled', ''),
(7, 'Bri', 'brianpacheca123@gmail.com', '2021-12-06 02:00:00', '2021-12-06 03:00:00', 'Confirmed', ''),
(8, 'Josh', 'brianpacheca123@gmail.com', '2021-12-06 04:00:00', '2021-12-06 05:00:00', 'Confirmed', ''),
(9, 'Josh', 'brianpacheca123@gmail.com', '2021-12-06 04:00:00', '2021-12-06 05:00:00', 'Cancelled', ''),
(10, 'Josh', 'brianpacheca123@gmail.com', '2021-12-06 04:00:00', '2021-12-06 05:00:00', 'Cancelled', ''),
(11, 'Josh', 'brianpacheca123@gmail.com', '2021-12-06 04:00:00', '2021-12-06 05:00:00', 'Cancelled', ''),
(12, 'Paulo', 'brianpacheca123@gmail.com', '2021-12-07 22:07:00', '2021-12-07 23:07:00', 'Confirmed', ''),
(13, 'Marvin', 'brianpacheca123@gmail.com', '2021-12-07 22:09:00', '2021-12-07 22:09:00', 'Cancelled', ''),
(42, '', 'brianpacheca123@gmail.com', '2022-01-25 05:00:00', '2022-01-25 07:00:00', 'Pending', ' '),
(43, '', 'brianpacheca123@gmail.com', '2022-01-25 07:00:00', '2022-01-25 09:00:00', 'Pending', ' '),
(44, '', 'brianpacheca123@gmail.com', '2022-01-25 02:00:00', '2022-01-25 04:00:00', 'Pending', ' '),
(45, '', 'brianpacheca123@gmail.com', '2022-01-25 02:00:00', '2022-01-25 04:00:00', 'Pending', ' '),
(41, '', 'brianpacheca123@gmail.com', '2022-01-25 03:00:00', '2022-01-25 04:00:00', 'Pending', ' '),
(40, '', 'brianpacheca123@gmail.com', '2022-01-25 02:00:00', '2022-01-25 03:00:00', 'Pending', ' '),
(47, '', 'brianpacheca123@gmail.com', '2022-01-25 16:00:00', '2022-01-25 18:00:00', 'Pending', ' '),
(46, '', 'brianpacheca123@gmail.com', '2022-01-25 14:00:00', '2022-01-25 16:00:00', 'Pending', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_settings`
--

CREATE TABLE `schedule_settings` (
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  `date_create` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule_settings`
--

INSERT INTO `schedule_settings` (`meta_field`, `meta_value`, `date_create`) VALUES
('day_schedule', 'Monday,Tuesday,Wednesday,Thursday,Friday', '2021-09-02 19:55:37'),
('morning_schedule', '08:00,11:00', '2021-09-02 19:55:37'),
('afternoon_schedule', '13:00,16:00', '2021-09-02 19:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

CREATE TABLE `tbl_admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_clients`
--

CREATE TABLE `tbl_clients` (
  `stud_id` int(11) NOT NULL,
  `stud_num` varchar(255) NOT NULL,
  `stud_pass` varchar(255) NOT NULL,
  `stud_name` varchar(255) NOT NULL,
  `stud_email` varchar(255) NOT NULL,
  `stud_contact` varchar(255) NOT NULL,
  `stud_guardian` varchar(255) NOT NULL,
  `guardian_contact` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userrole`
--

CREATE TABLE `userrole` (
  `RoleID` int(11) NOT NULL,
  `Description` varchar(25) CHARACTER SET latin1 NOT NULL,
  `ForPage` varchar(50) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`RoleID`, `Description`, `ForPage`) VALUES
(1, 'Student', 'Client'),
(2, 'Administrator', 'Administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientaccountinfo`
--
ALTER TABLE `clientaccountinfo`
  ADD PRIMARY KEY (`ClientAccountID`),
  ADD KEY `gender_role` (`ClientGenderID`),
  ADD KEY `user_role` (`RoleID`);

--
-- Indexes for table `genderrole`
--
ALTER TABLE `genderrole`
  ADD PRIMARY KEY (`GenderID`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `userrole`
--
ALTER TABLE `userrole`
  ADD PRIMARY KEY (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientaccountinfo`
--
ALTER TABLE `clientaccountinfo`
  MODIFY `ClientAccountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `genderrole`
--
ALTER TABLE `genderrole`
  MODIFY `GenderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userrole`
--
ALTER TABLE `userrole`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clientaccountinfo`
--
ALTER TABLE `clientaccountinfo`
  ADD CONSTRAINT `gender_role` FOREIGN KEY (`ClientGenderID`) REFERENCES `genderrole` (`GenderID`),
  ADD CONSTRAINT `user_role` FOREIGN KEY (`RoleID`) REFERENCES `userrole` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
