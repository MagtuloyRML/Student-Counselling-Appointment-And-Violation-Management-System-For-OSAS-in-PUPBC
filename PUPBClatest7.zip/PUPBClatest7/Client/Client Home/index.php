<?php
    $title = 'Home';
    $page = 'client_home';
    include_once('../includes/header.php');
?>

</body>

</html>