<?php

//import.php

include 'vendor/autoload.php';

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if($_FILES["import_excel"]["name"] != '')
{
 $allowed_extension = array('xls', 'csv', 'xlsx');
 $file_array = explode(".", $_FILES["import_excel"]["name"]);
 $file_extension = end($file_array);

 if(in_array($file_extension, $allowed_extension))
 {
  $file_name = time() . '.' . $file_extension;
  move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
  $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
  $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

  $spreadsheet = $reader->load($file_name);

  unlink($file_name);

  $data = $spreadsheet->getActiveSheet()->toArray();

  foreach($data as $row)
  {
   $insert_data = array(
    ':first_name'  => $row[0],
    ':last_name'  => $row[1],
    ':created_at'  => $row[2],
    ':updated_at'  => $row[3]
   );
   
   $query = "
   INSERT INTO sample_datas 
   (first_name, last_name, created_at, updated_at) 
   VALUES (:first_name, :last_name, :created_at, :updated_at)
   ";

   $statement = $connect->prepare($query);
   $statement->execute($insert_data);
  }
  $message = '<div class="alert alert-success">Data Imported Successfully</div>';

 }
 else
 {
  $message = '<div class="alert alert-danger">Only .xls .csv or .xlsx file allowed</div>';
 }
}
else
{
 $message = '<div class="alert alert-danger">Please Select File</div>';
}

echo $message;



I use this method for skip header :

    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load('FILE.xlsx');
    $sheetData = array();
    
    foreach ($spreadsheet->getWorksheetIterator() as $worksheet) {
        $worksheetTitle = $worksheet->getTitle();
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);
    
        for ($row = 1; $row <= $highestRow; ++$row) {
            for ($col = 0; $col <= $highestColumnIndex; ++$col) {
                $cell = $worksheet->getCellByColumnAndRow($col, $row);
                $val = $cell->getValue();
                $sheetData[$row][$col] = $val;
            }
        }
    }
    
    unset($sheetData[1]); // SKIP HEADER
    
    foreach ($sheetData as $val) {
      // set data for upload DB
     }


     $file_name = time() . '.' . $file_extension;
     move_uploaded_file($_FILES['file_path']['tmp_name'], $file_name);
     $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
     $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

     $spreadsheet = $reader->load($file_name);

     unlink($file_name);

     $data = $spreadsheet->getActiveSheet()->toArray();

     foreach($data as $row)
     {
         $insert_data = array(
             ':pcode'  => $row[0],
             ':description'  => $row[1]
         );
     

         $query = "
         INSERT INTO forprogram
         (courseCode, courseDescription) 
         VALUES (:pcode, :description)
         ";

         $statement = $connect->prepare($query);
         $statement->execute($insert_data);
     }
     $message = '<div class="alert alert-success">Data Imported Successfully</div>';
    

     $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = '$pcode' ";
            $check = mysqli_query($conn, $checkExistingCode);
            $updatestatement = $conn->prepare($checkExistingCode);
            $updatestatement->execute($insert_data);

            if(mysqli_num_rows($check) > 0){
                $update_data = "UPDATE forprogram SET courseCode = '$pcode', courseDescription = '$description' WHERE courseCode = '$pcode' ";
                $updatestatement = $conn->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $ins_data = "INSERT INTO forprogram (courseCode, courseDescription) VALUES ('$pcode', '$description')";
                $insertstatement = $conn->prepare($ins_data);
                $insertstatement->execute($insert_data);
            }

            $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = '$pcode' ";
            $check = mysqli_query($conn, $checkExistingCode);
            $updatestatement = $conn->prepare($checkExistingCode);
            $updatestatement->execute($insert_data);

            if(mysqli_num_rows($check) > 0){
                $update_data = "UPDATE forprogram SET courseCode = '$pcode', courseDescription = '$description' WHERE courseCode = '$pcode' ";
                $updatestatement = $conn->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $ins_data = "INSERT INTO forprogram (courseCode, courseDescription) VALUES ('$pcode', '$description')";
                $insertstatement = $conn->prepare($ins_data);
                $insertstatement->execute($insert_data);
            }

            $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = :pcode ";
            $checkresult = $connect->prepare($checkExistingCode);
            $checkresult->execute($insert_data);
            $result = $checkresult->fetchAll(PDO::FETCH_ASSOC);

            $num_rows = mysqli_num_rows($result);

            if ($num_rows > 0) {
                $update_data = "
                UPDATE forprogram
                SET courseCode = :pcode, 
                courseDescription = :description
                WHERE courseCode = :pcode ";
                $updatestatement = $connect->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $query = "
                INSERT INTO forprogram
                (courseCode, courseDescription) 
                VALUES (:pcode, :description)
                ";

                $statement = $connect->prepare($query);
                $statement->execute($insert_data);
            }
?>



<!DOCTYPE html>
<html>
<head>
	<title>Insert data in MySQL database using Ajax</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div style="margin: auto;width: 60%;">
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
	<form id="fupForm" name="form1" method="post">
		<div class="form-group">
			<label for="email">Name:</label>
			<input type="text" class="form-control" id="name" placeholder="Name" name="name">
		</div>
		<div class="form-group">
			<label for="pwd">Email:</label>
			<input type="email" class="form-control" id="email" placeholder="Email" name="email">
		</div>
		<div class="form-group">
			<label for="pwd">Phone:</label>
			<input type="text" class="form-control" id="phone" placeholder="Phone" name="phone">
		</div>
		<div class="form-group" >
			<label for="pwd">City:</label>
			<select name="city" id="city" class="form-control">
				<option value="">Select</option>
				<option value="Delhi">Delhi</option>
				<option value="Mumbai">Mumbai</option>
				<option value="Pune">Pune</option>
			</select>
		</div>
		<input type="button" name="save" class="btn btn-primary" value="Save to database" id="butsave">
	</form>
</div>

<script>
$(document).ready(function() {
$('#butsave').on('click', function() {
$("#butsave").attr("disabled", "disabled");
var name = $('#name').val();
var email = $('#email').val();
var phone = $('#phone').val();
var city = $('#city').val();
if(name!="" && email!="" && phone!="" && city!=""){
	$.ajax({
		url: "save.php",
		type: "POST",
		data: {
			name: name,
			email: email,
			phone: phone,
			city: city				
		},
		cache: false,
		success: function(dataResult){
			var dataResult = JSON.parse(dataResult);
			if(dataResult.statusCode==200){
				$("#butsave").removeAttr("disabled");
				$('#fupForm').find('input:text').val('');
				$("#success").show();
				$('#success').html('Data added successfully !'); 						
			}
			else if(dataResult.statusCode==201){
				alert("Error occured !");
			}
			
		}
	});
	}
	else{
		alert('Please fill all the field !');
	}
});
});
</script>
</body>
</html>
  
save.php
<?php
	include 'database.php';
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$city=$_POST['city'];
	$sql = "INSERT INTO `crud`( `name`, `email`, `phone`, `city`) 
	VALUES ('$name','$email','$phone','$city')";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>
 
	var fst_name = $('#fst_name').val(); var errorfst_name = false;
	var mid_name = $('#mid_name').val();  var errormid_name = false;
	var last_name = $('#last_name').val();  var errorlast_name = false;
	var suf_name = $('#suf_name').val();  var errorsuf_name = false;
	var stud_num = $('#stud_num').val();  var errorstud_num = false;
	var client_email = $('#client_email').val();  var errorclient_email = false;
	var password = $('#password').val();  var errorpassword = false;
	var cpassword = $('#cpassword').val();  var errorpassword2 = false;
	var bday = $('#bday').val();  var errorbday = false;
	var add = $('#add').val();   var erroradd = false;
	var gender = $('#gender').val();  var errorgender = false;
	var client_contact = $('#client_contact').val();  var errorclient_contact = false;
	var guar_name = $('#guar_name').val();  var errorguar_name = false;
	var guardian_contact = $('#guardian_contact').val();  var errorguardian_contact = false;

        var fst_name = $('#fst_name').val(); 
        var mid_name = $('#mid_name').val();  
        var last_name = $('#last_name').val();  
        var suf_name = $('#suf_name').val();  
        var stud_num = $('#stud_num').val();  
        var client_email = $('#client_email').val();  
        var password = $('#password').val();  
        var cpassword = $('#cpassword').val(); 
        var bday = $('#bday').val(); 
        var add = $('#add').val();   
        var gender = $('#gender').val();  
        var client_contact = $('#client_contact').val(); 
        var guar_name = $('#guar_name').val();  
        var guardian_contact = $('#guardian_contact').val(); 

    $.ajax({
            url:"assets/upload_curri.php",
            method:"POST",
            data:new FormData(this),
            contentType:false,
            cache:false,
            processData:false,
            beforeSend:function(){
                $('#uploadFunction').attr('disabled', 'disabled');
                $('#uploadFunction').text('Uploading...');
            },
            success:function(data)
            {
                $('#message').html(data);
                $('#uploadExcelFile')[0].reset();
                $('#uploadFunction').attr('disabled', false);
                $('#uploadFunction').text('Upload');
                $("#table").load("assets/updatedDisplay_pcode.php");
                

            }
        })

        $("#registration").submit(function(event){
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "assets/client_registration_process.php",
            data:new FormData(this),
            dataType: "json",
            contentType:false,
            cache:false,
            processData:false,
        });
    })